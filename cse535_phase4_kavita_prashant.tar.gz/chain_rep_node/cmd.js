function cmdArg() {
    var a = process.argv.splice(2);
    console.log(a[0]) ;   
}
cmdArg();

